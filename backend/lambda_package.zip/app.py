import json
import boto3

# Initialize Bedrock Runtime client
bedrock = boto3.client("bedrock-runtime", region_name="eu-central-1")

def select_model(user_input: str) -> str:
    """Select the right Bedrock model based on task type."""
    text = user_input.lower()
    if any(k in text for k in ["summarize", "explain", "analyze"]):
        return "anthropic.claude-3-sonnet-20240229-v1:0"
    elif any(k in text for k in ["code", "python", "api", "function", "develop"]):
        return "mistral.mistral-large-2402-v1:0"
    elif any(k in text for k in ["creative", "story", "ad copy", "write", "generate"]):
        return "meta.llama3-70b-instruct-v1:0"
    else:
        return "anthropic.claude-3-sonnet-20240229-v1:0"

def lambda_handler(event, context):
    try:
        # Parse incoming event
        if "body" in event:
            body = json.loads(event["body"])
        else:
            body = event

        user_input = body.get("input", "").strip()
        if not user_input:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Missing input text"})
            }

        # Dynamically pick the right model
        model_id = select_model(user_input)

        # Construct prompt
        prompt = f"""
        You are Harmony AI — the intelligent strategist behind Harmony Marketing Hub.
        Respond with clarity, brevity, and business insight.

        Task: {user_input}
        """

        # Invoke Bedrock model
        response = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps({
                "messages": [
                    {"role": "user", "content": [{"type": "text", "text": prompt}]}
                ],
                "max_tokens": 400,
                "temperature": 0.7,
                "top_p": 0.9
            }),
            contentType="application/json",
            accept="application/json"
        )

        # Parse Bedrock response
        response_body = json.loads(response["body"].read())

        # Extract text safely
        model_output = (
            response_body.get("output_text")
            or (response_body.get("content", [{}])[0].get("text", "No response generated."))
        )

        # Return success
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "input": user_input,
                "model_used": model_id,
                "output": model_output.strip()
            })
        }

    except Exception as e:
        # Catch all runtime errors
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": str(e)})
        }
